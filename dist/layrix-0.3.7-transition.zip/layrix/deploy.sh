#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/.env"

EXCLUDE=(
    ".env"
    "deploy.sh"
    ".git"
    ".gitignore"
    ".claude"
    ".vscode"
    ".DS_Store"
    "tmp"
    "node_modules"
    "tests"
    "scripts"
    "playwright.config.js"
    "package.json"
    "package-lock.json"
    "test-results"
    "website-quality-check"
)

upload_file() {
    local local_file="$1"
    local rel_path="${local_file#$SCRIPT_DIR/}"
    local remote_path="$FTP_PLUGIN_PATH/$rel_path"
    local remote_dir=$(dirname "$remote_path")

    # Create remote directory (ignore errors if exists)
    curl -s --ftp-ssl --ftp-create-dirs \
        -u "$FTP_USER:$FTP_PASS" \
        --insecure \
        --upload-file "$local_file" \
        "ftp://$FTP_HOST$remote_path" 2>/dev/null || \
    curl -s \
        -u "$FTP_USER:$FTP_PASS" \
        --upload-file "$local_file" \
        "ftp://$FTP_HOST$remote_path"
}

is_excluded() {
    local file="$1"
    for excl in "${EXCLUDE[@]}"; do
        if [[ "$file" == *"$excl"* ]]; then
            return 0
        fi
    done
    return 1
}

deploy_file() {
    local file="$1"
    local local_file="$file"

    if [[ "$local_file" != /* ]]; then
        local_file="$SCRIPT_DIR/$local_file"
    fi

    if [[ ! -f "$local_file" ]]; then
        echo "  skipping missing file: ${file#$SCRIPT_DIR/}"
        return 0
    fi

    if is_excluded "$local_file"; then
        echo "  skipping excluded file: ${local_file#$SCRIPT_DIR/}"
        return 0
    fi

    echo "  uploading: ${local_file#$SCRIPT_DIR/}"
    upload_file "$local_file"
    ((count+=1))
}

deploy_changed_files() {
    local changed_file
    while IFS= read -r changed_file; do
        [[ -z "$changed_file" ]] && continue
        deploy_file "$changed_file"
    done < <(
        {
            git -C "$SCRIPT_DIR" diff --name-only --diff-filter=ACMRT HEAD --
            git -C "$SCRIPT_DIR" diff --cached --name-only --diff-filter=ACMRT --
            git -C "$SCRIPT_DIR" ls-files --others --exclude-standard
        } | sort -u
    )
}

deploy_all_files() {
    local file
    while IFS= read -r -d '' file; do
        deploy_file "$file"
    done < <(find "$SCRIPT_DIR" -type f -print0)
}

mode="changed"
if [[ "${1:-}" == "--all" ]]; then
    mode="all"
    shift
elif [[ "${1:-}" == "--changed" ]]; then
    shift
fi

echo "Deploying elementor-core-framework to $FTP_HOST ..."

count=0
if [[ "$mode" == "all" ]]; then
    deploy_all_files
elif [[ "$#" -gt 0 ]]; then
    for file in "$@"; do
        deploy_file "$file"
    done
else
    deploy_changed_files
fi

echo ""
echo "Fertig! $count Dateien hochgeladen."
